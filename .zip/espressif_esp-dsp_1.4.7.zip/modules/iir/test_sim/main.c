
void test_iir_biquad();

int main(void)
{
    printf("main starts!\n");
//    xt_iss_profile_enable();
    test_iir_biquad();
//    xt_iss_profile_disable();

    printf("Test done\n");
}
