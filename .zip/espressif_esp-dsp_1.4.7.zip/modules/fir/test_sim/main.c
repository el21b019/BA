
void test_fir();

int main(void)
{
    printf("main starts!\n");
//    xt_iss_profile_enable();
    test_fir();
//    xt_iss_profile_disable();

    printf("Test done\n");
}
